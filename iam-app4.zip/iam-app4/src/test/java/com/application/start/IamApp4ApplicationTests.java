package com.application.start;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IamApp4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
