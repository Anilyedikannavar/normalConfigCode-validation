package com.application.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.application.processor.RequestProcessor;
import com.application.services.BookmarkService;
import com.application.services.CollectionService;

@RestController
@RequestMapping("/api")
public class RequestController {

	@Autowired
	private RequestProcessor requestProcessor;
	
	@Autowired
	private CollectionService collectionService;
	
	@Autowired
	private BookmarkService bookmarkService;

	@PostMapping(value = "/{action}/{entity}")
	public ResponseEntity handleHttpRequest(@RequestBody Map<String, Object> requestData,@PathVariable String entity, @PathVariable String action) {
		
		return requestProcessor.handleAction(action,entity, requestData);
	}
		
   @GetMapping(value = "/{action}/{entity}/{id}")
	public ResponseEntity handleHttpGetRequestWithId(@PathVariable String action,
	                                                 @PathVariable String entity,
	                                                 @PathVariable Long id,
	                                                 @RequestParam(required = false) Map<String, String> queryParams,
	                                                 @RequestBody(required = false) Map<String, Object> requestBody) {
	    // Handle the scenario: Action specific endpoint + Entity + ID
	    // Example: /api/getUsersById/user/123
	    return constructGet(action, entity, id, null, queryParams, requestBody);
	}

	@GetMapping(value = "/{action}/{entity}/getall")
	public ResponseEntity handleHttpGetRequestForAll(@PathVariable String action,
	                                                  @PathVariable String entity,
	                                                  @RequestParam(required = false) Map<String, String> queryParams,
	                                                  @RequestBody(required = false) Map<String, Object> requestBody) {
	    // Handle the scenario: Action specific endpoint + Entity + Get All
	    // Example: /api/getall/user
	    return constructGet(action, entity, null, null, queryParams, requestBody);
	}

	@GetMapping(value = "/{action}/{entity}/getByName")
	public ResponseEntity handleHttpGetRequestForName(@PathVariable String action,
			                                          @PathVariable String entity,
	                                                  @RequestParam String name,
	                                                 @RequestParam(required = false) Map<String, String> queryParams,
	                                                @RequestBody(required = false) Map<String, Object> requestBody) {
		
	    if ("Collections".equals(entity)) {
	        // Call the getByAppName method in ApplicationService
	        return collectionService.getCollectionsByName(name);
	        
	    } else if ("Bookmark".equals(entity)) {
	        // Call the getGroupsByName method in GroupService
	        return bookmarkService.getBookmarksByTitle(name);  
	    
//	    else if ("permission".equals(entity)) {
//	        // Call the getGroupsByName method in GroupService
//	        return permissionService.getByPermissionName(name); 
	    } else {
	        // Handle other entities or unknown entities
	        return constructGet(action, entity, null, name, queryParams, requestBody);
	    }
	}
	

//    @GetMapping(value = "/{action}/{entity}/getByName")
//    public ResponseEntity handleHttpGetRequestForName(@PathVariable String action,
//                                                      @PathVariable String entity,
//                                                      @RequestParam String name,
//                                                      @RequestParam(required = false) Map<String, String> queryParams,
//                                                      @RequestBody(required = false) Map<String, Object> requestBody) {
//        // Handle the scenario: Action specific endpoint + Entity + Name
//        // Example: /api/getByName/user?name=John
//        if ("user".equals(entity)) {
//            return getUsersByName(action, name, queryParams, requestBody);
//        } else if ("someOtherEntity".equals(entity)) {
//            return getSomeOtherEntityByName(action, name, queryParams, requestBody);
//        }
//
//        // Handle unknown entity
//        return ResponseEntity.badRequest().body("Unknown entity: " + entity);
//    }

	
	

	// Default mapping for cases where entity and id are not provided
//	@GetMapping(value = "/{action}")
//	public ResponseEntity handleHttpGetRequest(@PathVariable String action,
//	                                           @RequestParam(required = false) Map<String, String> queryParams,
//	                                           @RequestBody(required = false) Map<String, Object> requestBody) {
//	    return ResponseEntity.badRequest().body("Invalid request parameters");
//	}
	
	@RequestMapping(value = "/{action}/{entity}", method = RequestMethod.GET)
	public ResponseEntity handleHttpGetRequestWithIdAndBody(
	        @PathVariable String action,
//	        @PathVariable String entity,
//	        @PathVariable Long id,
	        @RequestParam(required = false) Map<String, String> queryParams,
	        @RequestBody(required = false) Map<String, Object> requestBody) {
	    
	    // Your logic here
	    
	    return constructGet(action, null,null,null, queryParams, requestBody);
	}

	
	private ResponseEntity constructGet(String action, String entity, Long id, String name,
	                                    Map<String, String> queryParams, Map<String, Object> requestBody) {
		
		 

	    // Construct requestData based on the parameters
	    Map<String, Object> requestData = new HashMap<>();
	    if (entity != null) {
	        requestData.put("entity", entity);
	    }
	    if (id != null) {
	        requestData.put("id", id);
	    }
	    if (name != null) {
	        requestData.put("name", name);
	    }

	    // Add query parameters to requestData if present
	    if (queryParams != null) {
	        requestData.putAll(queryParams);
	    }

	    // Add request body parameters to requestData if present
	    if (requestBody != null) {
	        requestData.putAll(requestBody);
	    }
	    
	 

	    // Delegate the handling of GET requests to RequestProcessor
       return requestProcessor.handleAction(action,entity, requestData);
	}
	
	

//	reqbody get pending yet to implement
	//Put and delete pending 

//	
//	@PutMapping(value = "/{action}/{entity}/{id}")
//	public ResponseEntity updateEntityById(@PathVariable String entity, @PathVariable Long id, @RequestBody Map<String, Object> requestData) {
//	    // Your logic here
//	    return constructPut("update", entity, id, null, requestData);
//	}
//
//	
//	
//	
//	@PutMapping(value = "/{update}/{entity}/{name}")
//	public ResponseEntity updateEntityByName(@PathVariable String entity, @RequestParam String name, @RequestBody Map<String, Object> requestData) {
//	    // Your logic here
//	    return constructPut("update", entity, null, name, requestData);
//	}

	
//	
//	@DeleteMapping(value = "/delete/{entity}/{id}")
//	public ResponseEntity deleteEntityById(@PathVariable String entity, @PathVariable Long id) {
//	    // Your logic here
//	    return constructDelete("delete", entity, id, null);
//	}
//	@DeleteMapping(value = "/delete/{entity}")
//	public ResponseEntity deleteEntityByName(@PathVariable String entity, @RequestParam String name) {
//	    // Your logic here
//	    return constructDelete("delete", entity, null, name);
//	}
//	private ResponseEntity constructPut(String action, String entity, Long id, String name, Map<String, Object> requestBody) {
//	    // Construct requestData based on the parameters
//	    Map<String, Object> requestData = new HashMap<>();
//	    if (entity != null) {
//	        requestData.put("entity", entity);
//	    }
//	    if (id != null) {
//	        requestData.put("id", id);
//	    }
//	    if (name != null) {
//	        requestData.put("name", name);
//	    }
//
//	    // Add request body parameters to requestData if present
//	    if (requestBody != null) {
//	        requestData.putAll(requestBody);
//	    }
//
//	    // Delegate the handling of PUT requests to RequestProcessor
//	    return requestProcessor.handleAction(action, requestData);
//	}

	
	
	
	
//	private ResponseEntity constructDelete(String action, String entity, Long id, String name) {
//	    // Construct requestData based on the parameters
//	    Map<String, Object> requestData = new HashMap<>();
//	    if (entity != null) {
//	        requestData.put("entity", entity);
//	    }
//	    if (id != null) {
//	        requestData.put("id", id);
//	    }
//	    if (name != null) {
//	        requestData.put("name", name);
//	    }
//
//	    // Delegate the handling of DELETE requests to RequestProcessor
//	    return requestProcessor.handleAction(action, requestData);
//	}
//
//	@PutMapping(value = "/{action}/{entity}/{id}")
//    public ResponseEntity updateEntityById(@PathVariable String action, @PathVariable String entity, @PathVariable Long id, @RequestBody Map<String, Object> requestData) {
//        return constructPut(action, entity, id, null, requestData);
//    }

//    @PutMapping(value = "/{action}/{entity}/updateByName")
//    public ResponseEntity updateEntityByName(@PathVariable String action, @PathVariable String entity, @RequestParam String name, @RequestBody Map<String, Object> requestData) {
//        return constructPut(action, entity, null, name, requestData);
//    }
	
	
//	@PutMapping(value = "/{action}/{entity}/updateByName")
//	public ResponseEntity updateEntityByName(@PathVariable String action, @PathVariable String entity, @RequestParam String name, @RequestBody Map<String, Object> requestData) {
//	    return constructPut(action, entity, null, name, requestData);
//	}
	
	
//	@PutMapping(value = "/{action}/{entity}/updateByName")
//	public ResponseEntity updateEntityByName(@PathVariable String action, @PathVariable String entity, @PathVariable String name, @RequestBody Map<String, Object> requestData) {
//	    return constructPut(action, entity, null, name, requestData);
//	}
//
//
//    private ResponseEntity constructPut(String action, String entity, Long id, String name, Map<String, Object> requestBody) {
//        Map<String, Object> requestData = new HashMap<>();
//        if (entity != null) {
//            requestData.put("entity", entity);
//        }
//        if (id != null) {
//            requestData.put("id", id);
//        }
//        if (name != null) {
//            requestData.put("name", name);
//        }
//        if (requestBody != null) {
//            requestData.putAll(requestBody);
//        }
//        return requestProcessor.handleAction(action,entity, requestData);
//    }
//
//	}  
	
	@PutMapping("/{action}/{variable}")
	public ResponseEntity handleHttpPutRequests(@PathVariable String action, @PathVariable String variable, @RequestBody Map<String, Object> requestData) {
	    System.out.println("Received PUT request. Action: " + action + ", Variable: " + variable);
	    // ... rest of the method
	    return requestProcessor.handlePutAction(action, variable, requestData);
	    
	}
	
	@DeleteMapping("/{action}/{variable}")
	public ResponseEntity handleDeleteAction(@PathVariable String action, @PathVariable String variable) {
	    System.out.println("Received DELETE request. Action: " + action + ", Variable: " + variable);
	    return requestProcessor.handleDeleteAction(action, variable);
	}
	
	
}