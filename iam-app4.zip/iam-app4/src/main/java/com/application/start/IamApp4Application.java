package com.application.start;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.application.repository.UsersRepository;

//@SpringBootApplication

@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })

@ComponentScan(basePackages = "com.application.config") // Add the correct package name
//@ComponentScan(basePackages = "com.application.validation.config")
@EntityScan(basePackages = "com.application.model") // Add the correct package name
@ComponentScan("com.application")
@ComponentScan(basePackages = "com.application.services") // Adjust the package path accordingly
@ComponentScan(basePackages = "com.application.security")
//@Import(SecurityConfig.class)
@ComponentScan(basePackages = "com.application.validation.config")
//@EnableJpaRepositories(basePackages = "com.application.repository")
//@EnableConfigurationProperties({ValidationConfig.class, SchemaMappingProperties.class})
@Configuration
//@EnableSwagger2
//@PropertySources({ @PropertySource("classpath:application.yml"), @PropertySource("classpath:application-validation.yml"),
//		@PropertySource("classpath:application-mapper.yml") })
@ComponentScan(basePackages = "com.application.mapper")
@EnableMongoRepositories(basePackageClasses = UsersRepository.class)
@ComponentScan
@ComponentScan(basePackages = "com.application.repository")
public class IamApp4Application {

	public static void main(String[] args) {
		SpringApplication.run(IamApp4Application.class, args);
	}

}
