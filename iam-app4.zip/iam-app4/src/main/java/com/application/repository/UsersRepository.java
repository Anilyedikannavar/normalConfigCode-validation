package com.application.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.application.model.Users;

@Repository
public interface UsersRepository extends MongoRepository<Users, String> {

	boolean existsByEmail(String email);

	Users findByEmail(String email);

//	Users findByname(String name);
//    List<Users> findById(Long User_Id);

//	Optional<Users> findByUser_Id(Long user_Id);	
	@Query("{ 'User_Id' : ?0 }")
	Optional<Users> findByUser_Id(Long userId); // Update the method name to findByUser_Id

	Optional<Users> findByname(String name);

	List<Users> findBynameIgnoreCase(String trim);

	@Query("{'email': ?0}")
	boolean updatePassword(String Email, String Password);

//	void save(Users newUser);
}
