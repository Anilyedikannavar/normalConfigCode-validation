package com.application.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.application.model.Collections;



@Repository
public interface CollectionRepository extends MongoRepository<Collections, String> {

	String existsByCollectionID(String collectionID);


	boolean existsByCollectionID(long collectionID);
	

	Optional<Collections> findByCollectionID(Long collectionId);


	List<Collections> findByCollectionNameIgnoreCase(String trim);


	Optional<Collections> findByCollectionName(String collectionName);

	@Query("{ 'collectionName' : ?0 }")
	Collections findByCollectionNameIgnoreCase1(String collectionName);


	Optional<Collections> findByCollectionName(CollectionRepository collectionRepository);


	


	
	
	
}