package com.application.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.application.model.Bookmark;

@Repository
public interface BookmarkRepository extends MongoRepository<Bookmark, String> {

	boolean existsByBookmarkID(long bookmarkID);

	Optional<Bookmark> findByBookmarkTitleIgnoreCase(String bookmarkTitle);

	
	@Query("{ 'bookmarkTitle' : ?0 }")
	Bookmark findByBookmarkTitleIgnoreCase1(String bookmarkTitle);

	

	


	
	
}