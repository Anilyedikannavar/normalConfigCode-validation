package com.application.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "iamenhance")
public class UserData {
	
	
	 private final String resetToken;
     private final long expirationTimeMillis;

     public UserData(String resetToken, long expirationTimeMillis) {
         this.resetToken = resetToken;
         this.expirationTimeMillis = expirationTimeMillis;
     }

     public String getResetToken() {
         return resetToken;
     }

     public boolean isTokenValid() {
         return System.currentTimeMillis() <= expirationTimeMillis;
     }
 }

