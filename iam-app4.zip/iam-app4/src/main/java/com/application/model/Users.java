package com.application.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Document(collection = "iamenhance")
public class Users {

	@Id
	@JsonIgnore
	private String id;
	@Field("User_Id")
	private long userId;
	
	private String name;
	private String companyName;
	private String email;
	private String password;

	public Users() {
		// Default constructor
	}

//    public Users(String name, String companyName, String email, String password) {
//        this.name = name;
//        this.companyName=companyName;
//        this.email = email;
//        this.password = password;
//    }

	public Users(long userId, String name, String companyName, String email, String password) {
		this.userId = userId;
		this.name = name;
		this.companyName = companyName;
		this.email = email;
		this.password = password;
	}

	// Getters and setters

	public long getuserId() {
		return userId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setuserId(long userId) {
		this.userId = userId;
	}

	public String getname() {
		return name;
	}

	public void setname(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

//	 public ObjectId getId() {
//	        return Id;
//	    }
//
//	    public void setId(ObjectId id) {
//	        this.Id = id;
//	    }

}
