package com.application.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Document(collection = "bookmark")
public class Bookmark {

	@Id
	@JsonIgnore
    private String id;

    @Field("bookmark_Id")
    private Long bookmarkID;

    private String url;

    @Field("bookmarkTitle")
    private String bookmarkTitle;

    @Field("bookmarkDescription")
    private String bookmarkDescription;

    // Reference to the parent Collections entity
    @Field("collectionId")
    private Long collectionId;

    @DBRef
    private Collections collections;

    // Constructors, getters, setters

    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getBookmarkID() {
		return bookmarkID;
	}

	public void setBookmarkID(Long bookmarkID) {
		this.bookmarkID = bookmarkID;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getBookmarkTitle() {
		return bookmarkTitle;
	}

	public void setBookmarkTitle(String bookmarkTitle) {
		this.bookmarkTitle = bookmarkTitle;
	}

	public String getBookmarkDescription() {
		return bookmarkDescription;
	}

	public void setBookmarkDescription(String bookmarkDescription) {
		this.bookmarkDescription = bookmarkDescription;
	}
    public Long getCollectionId() {
        return collectionId;
    }

    public void setCollectionId(Long collectionId) {
        this.collectionId = collectionId;
    }

    public Collections getCollections() {
        return collections;
    }

    public void setCollections(Collections collections) {
        this.collections = collections;
    }
}
