package com.application.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;

@Document(collection = "collections")
public class Collections {
	
	@Id
	@JsonIgnore
    private String id;

    @Field("collection_Id")
    private Long collectionID;

    @Field("collectionName")
    private String collectionName;

    @Field("collectionDescription")
    private String collectionDescription;

    // Embedding bookmarks within the collection
    private List<Bookmark> bookmarks;

    // Constructors, getters, setters


    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getCollectionID() {
		return collectionID;
	}

	public void setCollectionID(Long collectionID) {
		this.collectionID = collectionID;
	}

	public String getCollectionName() {
		return collectionName;
	}

	public void setCollectionName(String collectionName) {
		this.collectionName = collectionName;
	}

	public String getCollectionDescription() {
		return collectionDescription;
	}

	public void setCollectionDescription(String collectionDescription) {
		this.collectionDescription = collectionDescription;
	}

	
    // Other getters and setters

    public List<Bookmark> getBookmarks() {
        return bookmarks;
    }

    public void setBookmarks(List<Bookmark> bookmarks) {
        this.bookmarks = bookmarks;
    }
}
