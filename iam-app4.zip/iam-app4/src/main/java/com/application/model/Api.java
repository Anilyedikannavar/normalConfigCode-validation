package com.application.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Document(collection="Api")
public class Api {
	
	@Id
	@JsonIgnore
	private String id;
	@Field("api_Id")
	private long apiId;
	
	private String apiName;
	private String apiDescription;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public long getApiId() {
		return apiId;
	}
	public void setApiId(long apiId) {
		this.apiId = apiId;
	}
	public String getApiName() {
		return apiName;
	}
	public void setApiName(String apiName) {
		this.apiName = apiName;
	}
	public String getApiDescription() {
		return apiDescription;
	}
	public void setApiDescription(String apiDescription) {
		this.apiDescription = apiDescription;
	}
	public Api(String id, long apiId, String apiName, String apiDescription) {
		super();
		this.id = id;
		this.apiId = apiId;
		this.apiName = apiName;
		this.apiDescription = apiDescription;
	}
	public Api() {
		super();
		
	}
	

}
