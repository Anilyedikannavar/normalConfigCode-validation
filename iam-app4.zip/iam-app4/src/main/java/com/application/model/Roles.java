package com.application.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Document(collection="Roles")
public class Roles {

	@Id
	@JsonIgnore
	private String id;
	@Field("Role_Id")
	private long roleId;
	
	private String roleName;
	private String roleDescription;
	
    public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public long getRoleId() {
		return roleId;
	}
	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getRoleDescription() {
		return roleDescription;
	}
	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}
	public Roles(String id, long roleId, String roleName, String roleDescription) {
		super();
		this.id = id;
		this.roleId = roleId;
		this.roleName = roleName;
		this.roleDescription = roleDescription;
	}
	public Roles() {
		super();
		
	}
	
	
}


