package com.application.processor;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.application.config.ActionConfig;
import com.application.config.ApiConfigProperties;

//
//import java.lang.reflect.InvocationTargetException;
//import java.lang.reflect.Method;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.ApplicationContext;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Component;
//
//import com.application.config.ActionConfig;
//import com.application.config.ApiConfigProperties;
//import com.application.services.AuthenticationServices;
////import com.application.services.GroupService;
//import com.application.validation.config.ValidationConfig;
//import com.application.validation.config.ValidationRule;
//
////import com.application.service.UserLoginService;
////import com.application.service.UserRegistrationService;
//
//@Component
//public class RequestProcessor {
//
//	// private final UserRegistrationService userRegistrationService;
//	//
//	// private final UserLoginService userLoginService;
//
//	// private final UserRegistrationService userRegistrationService;
//	// private final UserLoginService userLoginService ;
//
//	private final ApplicationContext applicationContext;
//	private final ApiConfigProperties apiConfigProperties;
//	private final AuthenticationServices authenticationServices;
//	private final ValidationConfig validationConfig;
//	private final ValidationRule validationRule;
//
//	@Autowired
//	public RequestProcessor(AuthenticationServices authenticationServices, ApplicationContext applicationContext,
//			ApiConfigProperties apiConfigProperties, ValidationConfig validationConfig) {
//
//		// this.userLoginService=userLoginService;
//		// this.userRegistrationService=userRegistrationService;
//		this.applicationContext = applicationContext;
//		this.apiConfigProperties = apiConfigProperties;
//		this.authenticationServices = authenticationServices;
//		this.validationConfig = validationConfig;
//		this.validationRule = new ValidationRule();
//
//	}
//
//	public ResponseEntity<String> handleAction(String action, Map<String, Object> requestData) {
//		ActionConfig actionConfig = apiConfigProperties.getActions().stream()
//				.filter(config -> config.getapi().equals(action)).findFirst().orElse(null);
//
//		if (actionConfig == null) {
//			System.out.println("Action not found: " + action);
//
//			return ResponseEntity.notFound().build();
//		}
//
//		String method = actionConfig.getMethod();
//		System.out.println("Service class: " + actionConfig.getServiceClass());
//		System.out.println("Service method: " + actionConfig.getServiceMethod());
//
//		// Log class and method names
//		try {
//			if ("POST".equals(method) || "GET".equals(method) || "PUT".equals(method) || "DELETE".equals(method)) {
//				Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
//				Object serviceInstance = applicationContext.getBean(serviceClass);
//				Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod(), Map.class);
//
//				serviceMethod.invoke(serviceInstance, requestData);
//				return ResponseEntity.ok("Action executed successfully!");
//			} else {
//				return ResponseEntity.badRequest().body("Invalid method for action " + action);
//			}
//		} catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException
//				| InvocationTargetException e) {
//			e.printStackTrace(); // Print the exception for debugging
//			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//					.body("Error executing action: " + e.getMessage());
//		}
//	}
//}

@Component
public class RequestProcessor {

	private final ApplicationContext applicationContext;
	private final ApiConfigProperties apiConfigProperties;

	@Autowired
	public RequestProcessor(ApplicationContext applicationContext, ApiConfigProperties apiConfigProperties) {
		this.applicationContext = applicationContext;
		this.apiConfigProperties = apiConfigProperties;
	}

	public ResponseEntity<String> handleAction(String action,String entity, Map<String, Object> requestData) {
//		ActionConfig actionConfig = apiConfigProperties.getActions().stream()
//				.filter(config -> config.getapi().equals(action)).findAny().orElse(null);
		ActionConfig actionConfig = apiConfigProperties.getActions().stream()
		        .filter(config -> {
		            String configEntity = config.getentity();
		            return configEntity != null && configEntity.equals(entity) && config.getapi().equals(action);
		        })
		        .findFirst()
		        .orElse(null);

		if (actionConfig == null) {
			System.out.println("Action not found: " + action);
			return ResponseEntity.notFound().build();
		}

		String method = actionConfig.getMethod();
		System.out.println("Service class: " + actionConfig.getServiceClass());
		System.out.println("Service method: " + actionConfig.getServiceMethod());

		try {
			if ("POST".equals(method) || "GET".equals(method) || "PUT".equals(method) || "DELETE".equals(method)) {
				if ("GET".equals(method) && "getUsersById".equals(action)) {
					// Special handling for GET request to get user by ID
					return handleGetUserById(actionConfig, (Long) requestData.get("id"));
				} else if ("GET".equals(method) && "getByName".equals(action)) {
					// Handle the "getByName" action
					return handleGetByName(actionConfig, (String) requestData.get("name"));
				} else if ("GET".equals(method) && "getAll".equals(action)) {
					// Handle the "getAll" action
					return handleGetAll(actionConfig);
				} else if ("PUT".equals(method) && "handlePutById".equals(action)) {
					return handlePutById(actionConfig, (Long) requestData.get("id"));
				} else if ("PUT".equals(method) && "handlePutByName".equals(action)) {
					return handlePutByName(actionConfig, (String) requestData.get("name"));
				} else if ("POST".equals(actionConfig.getapi()) && "forgotPassword".equals(actionConfig.getServiceMethod())) {
			        return handleForgotPassword(actionConfig);
			    } else if ("POST".equals(actionConfig.getapi()) && "resetPassword".equals(actionConfig.getServiceMethod())) {
			        return handleResetPassword(actionConfig, requestData);
			    }
				Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
				Object serviceInstance = applicationContext.getBean(serviceClass);
				Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod(), Map.class);

				serviceMethod.invoke(serviceInstance, requestData);
				return ResponseEntity.ok("Action executed successfully!");
			} else {
				return ResponseEntity.badRequest().body("Invalid method for action " + action);
			}
		} catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException
				| InvocationTargetException e) {
			e.printStackTrace(); // Print the exception for debugging
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error executing action: " + e.getMessage());
		}
	}


	private ResponseEntity<String> handleGetUserById(ActionConfig actionConfig, Long id) {
		try {
			Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
			Object serviceInstance = applicationContext.getBean(serviceClass);
			Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod(), Long.class);

			serviceMethod.invoke(serviceInstance, id);
			return ResponseEntity.ok("GET request for user by ID handled successfully!");
		} catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException
				| InvocationTargetException e) {
			e.printStackTrace(); // Handle the exception appropriately in your application
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error handling GET request for user by ID: " + e.getMessage());
		}
	}

//	private ResponseEntity<String> handleGetByName(ActionConfig actionConfig, String name) {
//		try {
//			Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
//			Object serviceInstance = applicationContext.getBean(serviceClass);
//			Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod(), String.class);
//			ResponseEntity<String> result = (ResponseEntity<String>) serviceMethod.invoke(serviceInstance, name);
//
//			serviceMethod.invoke(serviceInstance, name);
//			return result;
//		} catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException
//				| InvocationTargetException e) {
//			e.printStackTrace(); // Handle the exception appropriately in your application
//			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//					.body("Error handling GET request for user by name: " + e.getMessage());
//		}
//
//	}
	
	
	private ResponseEntity<String> handleGetByName(ActionConfig actionConfig, String name) {
	    try {
	        Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
	        Object serviceInstance = applicationContext.getBean(serviceClass);
	        Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod(), String.class);

	        ResponseEntity<Object> result = (ResponseEntity<Object>) serviceMethod.invoke(serviceInstance, name);

	        // If you need to convert the result to a String, you can do so here
	        String resultAsString = result.getBody().toString();

	        return ResponseEntity.ok(resultAsString);
	    } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException
	            | InvocationTargetException e) {
	        e.printStackTrace(); // Handle the exception appropriately in your application
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body("Error handling GET request for user by name: " + e.getMessage());
	    }
	}


//	private ResponseEntity<String> handleGetAll(ActionConfig actionConfig) {
//		try {
//			Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
//			Object serviceInstance = applicationContext.getBean(serviceClass);
//			Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod());
//
//			serviceMethod.invoke(serviceInstance);
//			return ResponseEntity.ok("GET request for all entities handled successfully!");
//		} catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException
//				| InvocationTargetException e) {
//			e.printStackTrace(); // Handle the exception appropriately in your application
//			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//					.body("Error handling GET request for all entities: " + e.getMessage());
//		}
//	}
	
	private ResponseEntity<String> handleGetAll(ActionConfig actionConfig) {
	    try {
	        Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
	        Object serviceInstance = applicationContext.getBean(serviceClass);
	        Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod());
	        ResponseEntity<String> result = (ResponseEntity<String>) serviceMethod.invoke(serviceInstance);
  
	        serviceMethod.invoke(serviceInstance);
	        return result;
	    } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException
	            | InvocationTargetException e) {
	        e.printStackTrace(); // Handle the exception appropriately in your application
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body("Error handling GET request for all entities: " + e.getMessage());
	    }
	}


	private ResponseEntity<String> handlePutById(ActionConfig actionConfig, Long id) {
		try {
			Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
			Object serviceInstance = applicationContext.getBean(serviceClass);
			Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod());
			serviceMethod.invoke(serviceInstance);
			return ResponseEntity.ok("update by Id Successful!");
		} catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException
				| InvocationTargetException e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error to update it by id :" + e.getMessage());
		}

	}

	private ResponseEntity<String> handlePutByName(ActionConfig actionConfig, String name) {
		try {
			Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
			Object sericeInstance = applicationContext.getBean(serviceClass);
			Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod());
			serviceMethod.invoke(sericeInstance);
			return ResponseEntity.ok("updated by name!");
		} catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException
				| InvocationTargetException e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error to update it by id :" + e.getMessage());
		}
	}

	
	public ResponseEntity<Object> handlePutAction(String action, String variable, Map<String, Object> requestData) {
	    // 1. Find the action configuration
		ActionConfig actionConfig = apiConfigProperties.getActions().stream()
				.filter(config -> config.getapi().equals(action)).findAny().orElse(null);

	    // 2. Verify the HTTP method
	    if (!actionConfig.getMethod().equals("PUT")) {
	        return ResponseEntity.badRequest().body("Invalid method for action " + action);
	    }

	    // 3. Load the service class and method
	    try {
	        Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
	        Object serviceInstance = applicationContext.getBean(serviceClass);
	        Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod(), String.class, Map.class);

	        // 4. Invoke the service method and handle response
	        Object result = serviceMethod.invoke(serviceInstance, variable, requestData);
	        if (result == null) {
	            return ResponseEntity.ok().build(); // No content to return
	        } else {
	            return ResponseEntity.ok(result); // Return the result
	        }
	    } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException
	            | InvocationTargetException e) {
	        // 5. Handle exceptions
//	        logger.error("Error executing action " + action, e); // Log the error
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body("Error executing action: " + e.getMessage());
	    }
	}
	private ResponseEntity<String> handleDeleteById(ActionConfig actionConfig, Long id) {
		try {
			Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
			Object serviceInstance = applicationContext.getBean(serviceClass);
			Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod());
			serviceMethod.invoke(serviceInstance);
			return ResponseEntity.ok("deleted By Id!!!!!!");
		} catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException
				| InvocationTargetException e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("not deleted by Id!" + e.getMessage());

		}

	}
	
	//handle the deleteAction
	 public ResponseEntity handleDeleteAction(String action, String variable) {
		  System.out.println("Handling POST request for action: " + action);
	     ActionConfig actionConfig = apiConfigProperties.getActions().stream()
	             .filter(config -> config.getapi().equals(action))
	             .findFirst()
	             .orElse(null);

	     if (actionConfig == null) {
	    	 System.out.println(actionConfig);
	         return ResponseEntity.notFound().build();
	        
	     }

	     String method = actionConfig.getMethod();
	     System.out.println("Service class: " + actionConfig.getServiceClass());
	     System.out.println("Service method: " + actionConfig.getServiceMethod());

	     try {
	         if ("DELETE".equals(method)) {
	             Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
	             Object serviceInstance = applicationContext.getBean(serviceClass);

	             // Assume that the service method takes the variable (userId) as a parameter
	             Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod(), String.class);

	             // Invoke the service method and capture the result
	             Object result = serviceMethod.invoke(serviceInstance, variable);

	             // Return the result in the response
	             return ResponseEntity.ok(result);
	         } else {
	             return ResponseEntity.badRequest().body("Invalid method for action " + action);
	         }
	     } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException
	             | InvocationTargetException e) {
	         e.printStackTrace(); // Print the exception for debugging
	         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                 .body("Error executing action: " + e.getMessage());
	     }
	 }
	public ResponseEntity<String> handleForgotPassword(ActionConfig actionConfig) {
	    try {
	        Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
	        Object serviceInstance = applicationContext.getBean(serviceClass);
	        Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod(), Map.class);
	        serviceMethod.invoke(serviceInstance, new HashMap<>()); // Pass an empty map for now
	        return ResponseEntity.ok("Forgot password initiated successfully!");
	    } catch (ClassNotFoundException | IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
	        e.printStackTrace();
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error initiating forgot password: " + e.getMessage());
	    }
	}

	public ResponseEntity<String> handleResetPassword(ActionConfig actionConfig, Map<String, Object> requestData) {
	    try {
	        Class<?> serviceClass = Class.forName(actionConfig.getServiceClass());
	        Object serviceInstance = applicationContext.getBean(serviceClass);
	        Method serviceMethod = serviceClass.getMethod(actionConfig.getServiceMethod(), Map.class);
	        serviceMethod.invoke(serviceInstance, requestData);
	        return ResponseEntity.ok("Password reset successfully!");
	    } catch (ClassNotFoundException | IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
	        e.printStackTrace();
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error resetting password: " + e.getMessage());
	    }
	}

	
	

}
