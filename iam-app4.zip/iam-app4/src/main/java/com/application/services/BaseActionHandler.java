package com.application.services;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.function.Consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

//@Service
@Component
public abstract class BaseActionHandler {

    @Autowired
    private Map<String, Consumer<Map<String, Object>>> actionHandlers;

    public BaseActionHandler() {
    	
    	
        // Use reflection to register all methods following a naming convention
        Method[] methods = this.getClass().getDeclaredMethods();
        for (Method method : methods) {
            System.out.println("Checking method: " + method.getName());

            if (method.getName().startsWith("handleAction")) 
           
            {
                String action = extractActionName(method.getName());
                System.out.println("Registering action handler for: " + action);

                actionHandlers.put(action, map -> invokeMethod(method, map));
            }
        }
    }
  
    public void handleAction(Map<String, Object> requestData) {
        String action = (String) requestData.get("action");
        System.out.println("Executing action: " + action); // Add this for debugging
        Consumer<Map<String, Object>> actionHandler = actionHandlers.get(action);
        if (actionHandler != null) {
            actionHandler.accept(requestData);
        } else {
            System.err.println("No action handler found for: " + action); // Add this for debugging
            unknownAction(requestData);
        }
    }

    private void unknownAction(Map<String, Object> requestData) {
        // TODO: Handle unknown action
    }

    private String extractActionName(String methodName) {
        // Extract action name from the method name (e.g., handleActionRegister -> "register")
        return methodName.substring("handleAction".length()).toLowerCase();
    }

    private void invokeMethod(Method method, Map<String, Object> requestData) {
        try {
            method.invoke(this, requestData);
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace(); // Handle or log the exception
        }
    }
}
