package com.application.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    @Autowired
    private JavaMailSender javaMailSender;

    public void sendResetEmail(String userEmail, String resetToken) {
        // In a real system, you would implement logic to send an email
        // This example uses JavaMailSender for simplicity

        String subject = "Password Reset";
        String body = "Dear user,\n\n"
                + "You have requested to reset your password. Please use the following link to reset your password:\n"
                + "Reset Link: http://Spring-IAM-Project/reset?token=" + resetToken + "\n\n"
                + "If you did not request this, please ignore this email.";

        // Send the email
        sendEmail(userEmail, subject, body);
    }

    private void sendEmail(String to, String subject, String body) {
        // In a real system, use JavaMailSender or a dedicated email service
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("yedikannavar.anil@gmail.com"); // Set your email here
        message.setTo(to);
        message.setSubject(subject);
        message.setText(body);

        try {
            javaMailSender.send(message);
            logger.info("Email sent successfully to: " + to);
        } catch (Exception e) {
            logger.error("Error sending email to: " + to, e);
            // Handle the exception appropriately in your application
        }
    }
}
