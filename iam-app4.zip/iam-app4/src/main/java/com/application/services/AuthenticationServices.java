
package com.application.services;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.application.model.UserData;
import com.application.model.Users;
import com.application.repository.UsersRepository;
import com.application.validation.config.ValidationConfig;
import com.application.validation.config.ValidationRule;

@Service
public class AuthenticationServices extends BaseActionHandler {

	@Autowired
	private UsersRepository usersRepository;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Autowired
	private ValidationConfig validationConfig;

	@Autowired
	private SequenceGeneratorService sequenceGeneratorService;
	
	
	
	
	
	 private static final Logger logger = LoggerFactory.getLogger(AuthenticationServices.class);

	    private Map<String, UserData> userDataStore = new HashMap<>();

	    @Autowired
	    private EmailService emailService;

//    private final MongoTemplate mongoTemplate;

	public AuthenticationServices(UsersRepository usersRepository, MongoTemplate mongoTemplate) {
		this.usersRepository = usersRepository;
//        this.mongoTemplate = mongoTemplate;

	}

	public void registerUser(Map<String, Object> requestData) {
		// Extract user registration data from the requestData map
		String email = (String) requestData.get("email");
		String password = (String) requestData.get("password");
		String name = (String) requestData.get("name");
		String companyName = (String) requestData.get("companyName");

		// Apply validation rules for each attribute
		validateAttribute(name, "name");
		validateAttribute(email, "email");

		// Check if the email is already registered
		if (usersRepository.existsByEmail(email)) {
			throw new IllegalArgumentException("Email already registered!");
		}

		// Generate user ID
		long userId = sequenceGeneratorService.generateSequence("User_Id", 100);
		System.out.println("Generated User Id: " + userId);

		// Hash the password before saving it to the database
		String hashedPassword = passwordEncoder.encode(password);

		// Create a new user entity and save it
		Users newUser = new Users();
		newUser.setuserId(userId);
		newUser.setEmail(email);
		newUser.setPassword(hashedPassword);
		newUser.setname(name);
		newUser.setCompanyName(companyName);
		usersRepository.save(newUser);
	}

	private void validateAttribute(String value, String attributeName) {
		Map<String, ValidationRule> userValidationRules = validationConfig.getRules().get("user");
		if (userValidationRules != null) {
			ValidationRule validationRule = userValidationRules.get(attributeName);
			if (validationRule != null) {
				int minLength = validationRule.getMinLength();
				int maxLength = validationRule.getMaxLength();
				String regex = validationRule.getRegex();
				String errorMessage = validationRule.getErrorMessage();

				if (value == null || value.length() < minLength || value.length() > maxLength
						|| !value.matches(regex)) {
					throw new IllegalArgumentException(errorMessage);
				}
			}
		}
	}

	public void loginUser(Map<String, Object> requestData) {
		// Extract user login data from the requestData map
		String email = (String) requestData.get("email");
		String password = (String) requestData.get("password");

		// Find the user by email
		Users users = usersRepository.findByEmail(email);
		// Check if the user exists
		if (users == null) {
			throw new IllegalArgumentException("User with this email does not exist!");
		}

		// Validate the provided password against the hashed password in the database
		if (!passwordEncoder.matches(password, users.getPassword())) {
			throw new IllegalArgumentException("Incorrect password!");
		}
	}

//    public Users getUserByName(Map<String, Object> requestData) {
//        String name = (String) requestData.get("name");
//        return usersRepository.findByname(name);
//    }
//    public Map<String, Object> getUsersById(Long userId) {
//        // Implement your logic to fetch user details from MongoDB based on the provided userId
//        // For example:
//        Query query = new Query(Criteria.where("User_Id").is(userId));
//        Map<String, Object> user = mongoTemplate.findOne(query, Map.class, "iamenhance");
//
//        if (user != null) {
//            // User found, return the user details
//            return user;
//        } else {
//            // User not found, return an appropriate response
//            return Map.of("message", "User not found for ID: " + userId);
//        }
//    }

//    public ResponseEntity<?> getUsersById(Long userId) {
//        // Implement your logic to fetch user details from MongoDB based on the provided userId
//        // For example:
//        Query query = new Query(Criteria.where("User_Id").is(userId));
//        Map<String, Object> user = mongoTemplate.findOne(query, Map.class, "iamenhance");
//
//        if (user != null) {
//            // User found, return the complete user document
//            return ResponseEntity.ok(user);
//        } else {
//            // User not found, return an appropriate response
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "User not found for ID: " + userId));
//        }
//    }

//    public ResponseEntity<?> getUsersById(Long userId) {
//        // Implement your logic to fetch user details from MongoDB based on the provided userId
//        Optional<Users> optionalUser = usersRepository.findByUser_Id(userId);
//        
//        return optionalUser.map(user -> ResponseEntity.ok(user))
//        		.orElseThrow();
//    }

	public ResponseEntity<?> getUsersById(Long userId) {
		// Implement your logic to fetch user details from MongoDB based on the provided
		// userId
		Optional<Users> optionalUser = usersRepository.findByUser_Id(userId);

		return optionalUser.map(user -> {
			System.out.println("User details: " + user.getEmail());
			System.out.println("User details: " + user.getId());
			System.out.println("User details: " + user.getname());
			System.out.println("User details: " + user.getCompanyName());

			return ResponseEntity.ok(user);
		}).orElseThrow();
	}

//    public Users getUserByName(String name) {
//        return usersRepository.findByname(name);
//    }
//    public Map<String, Object> getUsersByName(String name) {
//        Users user = usersRepository.findByname(name);
//
//        if (user != null) {
//            Map<String, Object> userMap = new HashMap<>();
//            userMap.put("userId", user.getuserId());
//            userMap.put("name", user.getname());
//            userMap.put("companyName", user.getCompanyName());
//            userMap.put("email", user.getEmail());
//            // Add other fields as needed
//
//            return userMap;
//        } else {
//            // Handle the case where the user is not found
//            return Collections.singletonMap("message", "User not found for name: " + name);
//        }}
// 

//    public ResponseEntity<Object> getUsersByName(String name) {
//        try {
//            Optional<Users> optionalUser = usersRepository.findBynameIgnoreCase(name.trim());
//
//            if (optionalUser.isPresent()) {
//                Users user = optionalUser.get();
//
//                Map<String, Object> userMap = new HashMap<>();
//                userMap.put("userId", user.getuserId());
//                userMap.put("name", user.getname());
//                userMap.put("companyName", user.getCompanyName());
//                userMap.put("email", user.getEmail());
//                // Add other fields as needed
//
//                return ResponseEntity.ok(userMap);
//            } else {
//                System.out.println("User not found for name: " + name);
//                // Handle the case where the user is not found
//                Map<String, String> responseMap = Collections.singletonMap("message", "User not found for name: " + name);
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
//            }
//        } catch (Exception e) {
//            // Log any exceptions for debugging
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonMap("error", e.getMessage()));
//        }
//    }

	public ResponseEntity<Object> getUsersByName(String name) {
		try {
			List<Users> usersList = usersRepository.findBynameIgnoreCase(name.trim());

			if (!usersList.isEmpty()) {
				List<Map<String, Object>> userList = usersList.stream().map(user -> {
					Map<String, Object> userMap = new HashMap<>();
					userMap.put("userId", user.getuserId());
					userMap.put("name", user.getname());
					userMap.put("companyName", user.getCompanyName());
					userMap.put("email", user.getEmail());
					// Add other fields as needed
					return userMap;
				}).collect(Collectors.toList());

				return ResponseEntity.ok(userList);
			} else {
				System.out.println("No users found for name: " + name);
				// Handle the case where no users are found
				Map<String, String> responseMap = Collections.singletonMap("message",
						"No users found for name: " + name);
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
			}
		} catch (Exception e) {
			// Log any exceptions for debugging
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(Collections.singletonMap("error", e.getMessage()));
		}
	}
//	
//	 public ResponseEntity<Object> getCollectionsByName(String name) {
//	        try {
//	            List<com.application.model.Collections> collectionsList = collectionRepository.findByCollectionNameIgnoreCase(name.trim());
//
//	            if (!collectionsList.isEmpty()) {
//	                List<Map<String, Object>> collectionList = collectionsList.stream().map(collection -> {
//	                    Map<String, Object> collectionMap = new HashMap<>();
//	                    collectionMap.put("collectionId", collection.getCollectionID());
//	                    collectionMap.put("collectionName", collection.getCollectionName());
//	                    collectionMap.put("collectionDescription", collection.getCollectionDescription());
//	                    // Add other fields as needed
//	                    return collectionMap;
//	                }).collect(Collectors.toList());
//
//	                return ResponseEntity.ok(collectionList);
//	            } else {
//	                System.out.println("No collections found for name: " + name);
//	                // Handle the case where no collections are found
//	                Map<String, String> responseMap = new HashMap<>();
//	                responseMap.put("message", "No collections found for name: " + name);
//	                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
//	            }
//	        } catch (Exception e) {
//	            // Log any exceptions for debugging
//	            e.printStackTrace();
//	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//	                    .body(new HashMap<String, String>(){{put("error", e.getMessage());}});
//	        }
//	    }

//    public ResponseEntity<Object> getAllUsers() {
//        try {
//            List<Users> allUsers = usersRepository.findAll();
//
//            if (!allUsers.isEmpty()) {
//                List<Map<String, Object>> userList = allUsers.stream()
//                        .map(user -> {
//                            Map<String, Object> userMap = new HashMap<>();
//                            userMap.put("userId", user.getuserId());
//                            userMap.put("name", user.getname());
//                            userMap.put("companyName", user.getCompanyName());
//                            userMap.put("email", user.getEmail());
//                            // Add other fields as needed
//                            return userMap;
//                        })
//                        .collect(Collectors.toList());
//
//                return ResponseEntity.ok(userList);
//            } else {
//                System.out.println("No users found.");
//                // Handle the case where no users are found
//                Map<String, String> responseMap = Collections.singletonMap("message", "No users found.");
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
//            }
//        } catch (Exception e) {
//            // Log any exceptions for debugging
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonMap("error", e.getMessage()));
//        }
//    }

//    public ResponseEntity<Object> getAllUsers() {
//        try {
//            List<Users> allUsers = usersRepository.findAll();
//
//            if (!allUsers.isEmpty()) {
//                List<Map<String, Object>> userList = allUsers.stream()
//                        .map(user -> {
//                            Map<String, Object> userMap = new HashMap<>();
//                            userMap.put("userId", user.getuserId());
//                            userMap.put("name", user.getname());
//                            userMap.put("companyName", user.getCompanyName());
//                            userMap.put("email", user.getEmail());
//                            // Add other fields as needed
//                            return userMap;
//                        })
//                        .collect(Collectors.toList());/

//                // Log the response body
//                System.out.println("Response Body: " + userList);
//
//                return ResponseEntity.ok(userList);
//            } else {
//                System.out.println("No users found.");
//                // Handle the case where no users are found
//                Map<String, String> responseMap = Collections.singletonMap("message", "No users found.");
//                System.out.println("Response Body: " + responseMap);
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
//            }
//        } catch (Exception e) {
//            // Log any exceptions for debugging
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonMap("error", e.getMessage()));
//        }

	public ResponseEntity<Object> getAllUsers() {
		try {
			List<Users> allUsers = usersRepository.findAll();

			if (!allUsers.isEmpty()) {
				List<Map<String, Object>> userList = allUsers.stream().map(user -> {
					Map<String, Object> userMap = new HashMap<>();
					userMap.put("userId", user.getuserId());

					// Check for null values before adding to the map
					if (user.getname() != null) {
						userMap.put("name", user.getname());
					}

					if (user.getCompanyName() != null) {
						userMap.put("companyName", user.getCompanyName());
					}

					if (user.getEmail() != null) {
						userMap.put("email", user.getEmail());
					}

					// Add other fields as needed
					return userMap;
				}).collect(Collectors.toList());

				// Log the response body
				System.out.println("Response Body: " + userList);

				return ResponseEntity.ok(userList);
			} else {
				System.out.println("No users found.");
				// Handle the case where no users are found
				Map<String, String> responseMap = Collections.singletonMap("message", "No users found.");
				System.out.println("Response Body: " + responseMap);
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
			}
		} catch (Exception e) {
			// Log any exceptions for debugging
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(Collections.singletonMap("error", e.getMessage()));
		}
	}
	
	
	

//    public ResponseEntity<String> forgotPassword(String userEmail) {
//        try {
//            if (isValidEmail(userEmail)) {
//                String resetToken = generateResetToken(userEmail);
//                long expirationTimeMillis = System.currentTimeMillis() + (30 * 60 * 1000); // 30 minutes expiration
//                userDataStore.put(userEmail, new UserData(resetToken, expirationTimeMillis));
//
//                // In a real system, send an email with the reset link containing the token
//                emailService.sendResetEmail(userEmail, resetToken);
//
//                return ResponseEntity.ok("Password reset initiated. Check your email for instructions.");
//            } else {
//                return ResponseEntity.badRequest().body("Invalid email address.");
//            }
//        } catch (Exception e) {
//            logger.error("Error initiating password reset for user: " + userEmail, e);
//            return ResponseEntity.status(500).body("Internal server error");
//        }
//    }
	
	
	public ResponseEntity<String> forgotPassword(Map<String, Object> requestData) {
	    try {
	        String userEmail = (String) requestData.get("email");

	        if (isValidEmail(userEmail)) {
	            String resetToken = generateResetToken(userEmail);
	            long expirationTimeMillis = System.currentTimeMillis() + (30 * 60 * 1000); // 30 minutes expiration
	            userDataStore.put(userEmail, new UserData(resetToken, expirationTimeMillis));

	            // In a real system, send an email with the reset link containing the token
	            emailService.sendResetEmail(userEmail, resetToken);

	            return ResponseEntity.ok("Password reset initiated. Check your email for instructions.");
	        } else {
	            return ResponseEntity.badRequest().body("Invalid email address.");
	        }
	    } catch (Exception e) {
	        logger.error("Error initiating password reset", e);
	        return ResponseEntity.status(500).body("Internal server error");
	    }
	}

    public ResponseEntity<String> resetPassword(String userEmail, String resetToken, String newPassword) {
        try {
            UserData userData = userDataStore.get(userEmail);
            if (userData != null && userData.getResetToken().equals(resetToken) && userData.isTokenValid()) {
                // Reset the password (In a real system, you would update the database)
                boolean passwordUpdated = usersRepository.updatePassword(userEmail, newPassword);

                if (passwordUpdated) {
                    logger.info("Password reset successfully for user: " + userEmail);
                    // Remove the used token
                    userDataStore.remove(userEmail);
                    return ResponseEntity.ok("Password reset successfully!");
                } else {
                    return ResponseEntity.status(500).body("Error updating password");
                }
            } else {
                return ResponseEntity.badRequest().body("Invalid or expired token");
            }
        } catch (Exception e) {
            logger.error("Error resetting password for user: " + userEmail, e);
            return ResponseEntity.status(500).body("Internal server error");
        }
    }

    // Other methods...

    private String generateResetToken(String userEmail) {
        SecureRandom secureRandom = new SecureRandom();
        byte[] tokenBytes = new byte[32];
        secureRandom.nextBytes(tokenBytes);
        return userEmail + "_" + Base64.getEncoder().encodeToString(tokenBytes);
    }

    private boolean isValidEmail(String userEmail) {
        // Simulated validation: Check if the email format is valid
        return userEmail.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");
    }

}
