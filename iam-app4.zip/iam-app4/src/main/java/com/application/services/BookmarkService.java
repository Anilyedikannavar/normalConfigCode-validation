package com.application.services;

import com.application.model.Bookmark;
import com.application.repository.BookmarkRepository;
import com.application.repository.CollectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BookmarkService {

	@Autowired
    private static BookmarkRepository bookmarkRepository;
    
    
    @Autowired
 	private SequenceGeneratorService sequenceGeneratorService;
 	

    
    public BookmarkService(BookmarkRepository bookmarkRepository) {
        this.bookmarkRepository = bookmarkRepository;
        
    }

    public ResponseEntity<Object> createBookmark(Map<String, Object> requestData) {
        try {
            // Extract bookmark registration data from the requestData map
            long bookmarkID = sequenceGeneratorService.generateSequence("Bookmark_Id", 100);
            String bookmarkTitle = (String) requestData.get("bookmarkTitle");
            String url = (String) requestData.get("url");
            // Assuming 'bookmarkDescription' is the correct attribute name
            String bookmarkDescription = (String) requestData.get("bookmarkDescription");

            // Check if the bookmarkID is already registered
            if (bookmarkRepository.existsByBookmarkID(bookmarkID)) {
                throw new IllegalArgumentException("Bookmark with ID " + bookmarkID + " already registered!");
            }

            // Create a new bookmark entity and save it
            Bookmark newBookmark = new Bookmark();
            newBookmark.setBookmarkID(bookmarkID);
            newBookmark.setBookmarkTitle(bookmarkTitle);
            newBookmark.setUrl(url);
            newBookmark.setBookmarkDescription(bookmarkDescription);
            Bookmark savedBookmark = bookmarkRepository.save(newBookmark);

            return ResponseEntity.status(HttpStatus.CREATED).body(savedBookmark);
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    public ResponseEntity<Object> getAllBookmarks() {
        try {
            List<Bookmark> allBookmarks = bookmarkRepository.findAll();

            if (!allBookmarks.isEmpty()) {
                List<Map<String, Object>> bookmarkList = allBookmarks.stream().map(bookmark -> {
                    Map<String, Object> bookmarkMap = new HashMap<>();
                    bookmarkMap.put("bookmarkId", bookmark.getBookmarkID());
                    // Check for null values before adding to the map
                    if (bookmark.getBookmarkTitle() != null) {
                        bookmarkMap.put("bookmarkTitle", bookmark.getBookmarkTitle());
                    }
                    if (bookmark.getUrl() != null) {
                        bookmarkMap.put("url", bookmark.getUrl());
                    }
                    if (bookmark.getBookmarkDescription() != null) {
                        bookmarkMap.put("bookmarkDescription", bookmark.getBookmarkDescription());
                    }
                    // Add other fields as needed

                    return bookmarkMap;
                }).collect(Collectors.toList());

                // Log the response body
                System.out.println("Response Body: " + bookmarkList);

                return ResponseEntity.ok(bookmarkList);
            } else {
                System.out.println("No bookmarks found.");
                // Handle the case where no bookmarks are found
                Map<String, String> responseMap = new HashMap<>();
                responseMap.put("message", "No bookmarks found.");
                System.out.println("Response Body: " + responseMap);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
            }
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            Map<String, String> errorMap = new HashMap<>();
            errorMap.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMap);
        }
    }

    public ResponseEntity<Object> getBookmarksByTitle(String title) {
        try {
            Optional<Bookmark> bookmarksList = bookmarkRepository.findByBookmarkTitleIgnoreCase(title.trim());

            if (!bookmarksList.isEmpty()) {
                List<Map<String, Object>> bookmarkList = bookmarksList.stream().map(bookmark -> {
                    Map<String, Object> bookmarkMap = new HashMap<>();
                    bookmarkMap.put("bookmarkId", bookmark.getBookmarkID());
                    bookmarkMap.put("bookmarkTitle", bookmark.getBookmarkTitle());
                    bookmarkMap.put("bookmarkDescription", bookmark.getBookmarkDescription());
                    bookmarkMap.put("url", bookmark.getUrl());
                    // Add other fields as needed
                    return bookmarkMap;
                }).collect(Collectors.toList());

                return ResponseEntity.ok(bookmarkList);
            } else {
                System.out.println("No bookmarks found for title: " + title);
                // Handle the case where no bookmarks are found
                Map<String, String> responseMap = new HashMap<>();
                responseMap.put("message", "No bookmarks found for title: " + title);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
            }
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new HashMap<String, String>(){{put("error", e.getMessage());}});
        }
    }

    public Optional<Bookmark> updateBookmarkByName(@PathVariable String bookmarkTitle, @RequestBody Map<String, Object> requestData) {
        try {
            // Find the existing bookmark by title
            Optional<Bookmark> optionalBookmark = bookmarkRepository.findByBookmarkTitleIgnoreCase(bookmarkTitle);

            // Check if the bookmark exists
            if (optionalBookmark.isPresent()) {
                Bookmark existingBookmark = optionalBookmark.get();

                // Update the bookmark details with the provided values in the requestData map
                if (requestData.containsKey("url")) {
                    existingBookmark.setUrl((String) requestData.get("url"));
                }

                if (requestData.containsKey("bookmarkTitle")) {
                    existingBookmark.setBookmarkTitle((String) requestData.get("bookmarkTitle"));
                }

                if (requestData.containsKey("bookmarkDescription")) {
                    existingBookmark.setBookmarkDescription((String) requestData.get("bookmarkDescription"));
                }

                // Update other fields as needed

                // Save the updated bookmark
                bookmarkRepository.save(existingBookmark);

                return optionalBookmark;
            } else {
                // Return an empty Optional if the bookmark is not found
                return Optional.empty();
            }
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            // Return an empty Optional for any exceptions
            return Optional.empty();
        }

    }
    
    public String deleteBookmarkByBookmarkTitle(String bookmarkTitle) {
        try {
            // Find the bookmark by bookmarkTitle
            Bookmark bookmarkToDelete = bookmarkRepository.findByBookmarkTitleIgnoreCase1(bookmarkTitle);

            // Check if the bookmark exists
            if (bookmarkToDelete != null) {
                // Delete the bookmark
                bookmarkRepository.delete(bookmarkToDelete);
                return "Deleted Bookmark Successfully";
            } else {
                // Return a message indicating that the bookmark was not found
                return "Bookmark with the specified title not found";
            }
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            // Return an error message
            return "Error deleting bookmark: " + e.getMessage();
        }
    }

}
