package com.application.services;

import com.application.model.Bookmark;
import com.application.model.Collections;
import com.application.repository.BookmarkRepository;
import com.application.repository.CollectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CollectionBookmarkService {

    private final CollectionRepository collectionRepository;
    private final BookmarkRepository bookmarkRepository;
    private final SequenceGeneratorService sequenceGeneratorService;

    @Autowired
    public CollectionBookmarkService(
            CollectionRepository collectionRepository,
            BookmarkRepository bookmarkRepository,
            SequenceGeneratorService sequenceGeneratorService) {
        this.collectionRepository = collectionRepository;
        this.bookmarkRepository = bookmarkRepository;
        this.sequenceGeneratorService = sequenceGeneratorService;
    }

    public Collections addBookmarksToCollection(Map<String, Object> requestData) {
        try {
            // Use the sequence generator service to generate the collectionID
            long collectionID = sequenceGeneratorService.generateSequence("collection_Id");

            // Extract other collection information from the requestData
            String collectionName = (String) requestData.get("collectionName");
            String collectionDescription = (String) requestData.get("collectionDescription");

            // Create a new Collections entity
            Collections newCollection = new Collections();
            newCollection.setCollectionID(collectionID);
            newCollection.setCollectionName(collectionName);
            newCollection.setCollectionDescription(collectionDescription);

            // Save the new collection first to generate its ID
            Collections savedCollection = collectionRepository.save(newCollection);

            // Extract bookmark information from the requestData
            List<Map<String, Object>> bookmarkDataList = (List<Map<String, Object>>) requestData.get("bookmark");

            // Create and save Bookmark entities
            List<Bookmark> bookmarks = bookmarkDataList.stream()
                    .map(bookmarkData -> {
                        // Use the sequence generator service to generate the bookmarkID
                        long bookmarkID = sequenceGeneratorService.generateSequence("bookmark_Id");

                        Bookmark bookmark = new Bookmark();
                        bookmark.setCollections(savedCollection); // Set the reference to the parent collection
                        bookmark.setBookmarkID(bookmarkID);
                        bookmark.setBookmarkTitle((String) bookmarkData.get("bookmarkTitle"));
                        bookmark.setUrl((String) bookmarkData.get("url"));
                        bookmark.setBookmarkDescription((String) bookmarkData.get("bookmarkDescription"));
                        // Set other properties as needed
                        return bookmarkRepository.save(bookmark); // Save and return the bookmark
                    })
                    .toList();

            // Associate the saved bookmarks with the saved collection
            savedCollection.setBookmarks(bookmarks);

            // Save the updated collection with references to bookmarks
            collectionRepository.save(savedCollection);

            // Return the saved collection
            return savedCollection;
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            // Handle the exception as needed and return an appropriate response
            return null;
        }
    }
}
