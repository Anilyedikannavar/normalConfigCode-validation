package com.application.services;

import com.application.model.Bookmark;
import com.application.model.Collections;
import com.application.repository.BookmarkRepository;
import com.application.repository.CollectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CollectionService {
	
	@Autowired
    private static CollectionRepository collectionRepository;
	
	@Autowired
	private BookmarkRepository  bookmarkRepository;
     
    @Autowired
	private SequenceGeneratorService sequenceGeneratorService;
	

    public CollectionService(CollectionRepository collectionRepository) {
        this.collectionRepository = collectionRepository;
    }

    public ResponseEntity<Object> createCollection(Map<String, Object> requestData) {
        try {
            // Extract collection registration data from the requestData map
            long collectionID = sequenceGeneratorService.generateSequence("collection_Id");
            String collectionName = (String) requestData.get("collectionName");
            String collectionDescription = (String) requestData.get("collectionDescription");

            // Check if the collectionID is already registered
            if (collectionRepository.existsByCollectionID(collectionID)) {
                throw new IllegalArgumentException("Collection with ID " + collectionID + " already registered!");
            }

            // Create a new collection entity and save it
            Collections newCollection = new Collections();
            newCollection.setCollectionID(collectionID);
            newCollection.setCollectionName(collectionName);
            newCollection.setCollectionDescription(collectionDescription);
            Collections savedCollection = collectionRepository.save(newCollection);

            return ResponseEntity.status(HttpStatus.CREATED).body(savedCollection);
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

   
    public ResponseEntity<Object> getAllCollections() {
        try {
            List<Collections> allCollections = collectionRepository.findAll();

            if (!allCollections.isEmpty()) {
                List<Map<String, Object>> collectionList = allCollections.stream().map(collection -> {
                    Map<String, Object> collectionMap = new HashMap<>();
                    collectionMap.put("collectionId", collection.getCollectionID());
                    // Check for null values before adding to the map
                    if (collection.getCollectionName() != null) {
                        collectionMap.put("collectionName", collection.getCollectionName());
                    }
                    if (collection.getCollectionDescription() != null) {
                        collectionMap.put("collectionDescription", collection.getCollectionDescription());
                    }
                    // Add other fields as needed

                    return collectionMap;
                }).collect(Collectors.toList());

                // Log the response body
                System.out.println("Response Body: " + collectionList);

                return ResponseEntity.ok(collectionList);
            } else {
                System.out.println("No collections found.");
                // Handle the case where no collections are found
                Map<String, String> responseMap = new HashMap<>();
                responseMap.put("message", "No collections found.");
                System.out.println("Response Body: " + responseMap);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
            }
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            Map<String, String> errorMap = new HashMap<>();
            errorMap.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMap);
        }
    }


    public  ResponseEntity<Object> getCollectionsByName(String name) {
        try {
            List<Collections> collectionsList = collectionRepository.findByCollectionNameIgnoreCase(name.trim());

            if (!collectionsList.isEmpty()) {
                List<Map<String, Object>> collectionList = collectionsList.stream().map(collection -> {
                    Map<String, Object> collectionMap = new HashMap<>();
                    collectionMap.put("collectionId", collection.getCollectionID());
                    collectionMap.put("collectionName", collection.getCollectionName());
                    collectionMap.put("collectionDescription", collection.getCollectionDescription());
                    // Add other fields as needed
                    return collectionMap;
                }).collect(Collectors.toList());

                return ResponseEntity.ok(collectionList);
            } else {
                System.out.println("No collections found for name: " + name);
                // Handle the case where no collections are found
                Map<String, String> responseMap = new HashMap<>();
                responseMap.put("message", "No collections found for name: " + name);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
            }
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new HashMap<String, String>(){{put("error", e.getMessage());}});
        }
    }
    
    public ResponseEntity<?> getCollectionById(Long collectionId) {
        // Implement your logic to fetch collection details from MongoDB based on the provided collectionId
        Optional<Collections> optionalCollection = collectionRepository.findByCollectionID(collectionId);

        return optionalCollection.map(collection -> {
            System.out.println("collectionName: " + collection.getCollectionName());
            System.out.println("collectionId: " + collection.getId());
            System.out.println("collectionDescription: " + collection.getCollectionDescription());

            return ResponseEntity.ok(collection);
        }).orElseThrow();
    }
   
    
//    public ResponseEntity<Object> updateCollectionByName(String name, Map<String, Object> requestData) {
//        try {
//            List<Collections> collectionsList = collectionRepository.findByCollectionNameIgnoreCase(name.trim());
//
//            if (!collectionsList.isEmpty()) {
//                Collections existingCollection = collectionsList.get(0);
//
//                // Update fields of the existing collection with the values from the updatedCollection
//                existingCollection.setCollectionName(requestData.getCollectionName());
//                existingCollection.setCollectionDescription(requestData.getCollectionDescription());
//                // Update other fields as needed
//
//                // Save the updated collection to the database
//                collectionRepository.save(existingCollection);
//
//                Map<String, Object> responseMap = new HashMap<>();
//                responseMap.put("message", "Collection updated successfully");
//                return ResponseEntity.ok(responseMap);
//            } else {
//                System.out.println("No collections found for name: " + name);
//                // Handle the case where no collections are found
//                Map<String, String> responseMap = new HashMap<>();
//                responseMap.put("message", "No collections found for name: " + name);
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
//            }
//        } catch (Exception e) {
//            // Log any exceptions for debugging
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(new HashMap<String, String>(){{put("error", e.getMessage());}});
//        }
//    }
      
    
    public Optional<Collections> updateCollectionByName(@PathVariable String collectionName, @RequestBody Map<String, Object> requestData) {
        try {
            // Find the existing collection by name
            Optional<Collections> optionalCollection = collectionRepository.findByCollectionName(collectionName);

            // Check if the collection exists
            if (optionalCollection.isPresent()) {
                Collections existingCollection = optionalCollection.get();

                // Update the collection details with the provided values in the requestData map
                if (requestData.containsKey("collectionName")) {
                    existingCollection.setCollectionName((String) requestData.get("collectionName"));
                }

                if (requestData.containsKey("collectionDescription")) {
                    existingCollection.setCollectionDescription((String) requestData.get("collectionDescription"));
                }

                // Update other fields as needed

                // Save the updated collection
                collectionRepository.save(existingCollection);

//                // Return a custom map in the response body
//                Map<String, Object> responseMap = new HashMap<>();
//                responseMap.put("message", "Collection updated successfully");
//                responseMap.put("updatedCollection", existingCollection);

                return optionalCollection;
            } else {
                // Return a not found response with an empty body
                return Optional.empty();
            }
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            // Return a 500 Internal Server Error response without an error field in the body
            return Optional.empty();
        }
    }
    
    
    public String deleteCollectionByCollectionName(String collectionName) {
        try {
            // Find the collection by collectionName
            Collections collectionToDelete = collectionRepository.findByCollectionNameIgnoreCase1(collectionName);

            // Check if the collection exists
            if (collectionToDelete != null) {
                // Delete the collection
                collectionRepository.delete(collectionToDelete);
                return "Deleted Collection Successfully";
            } else {
                // Return a message indicating that the collection was not found
                return "Collection with the specified name not found";
            }
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            // Return an error message
            return "Error deleting collection: " + e.getMessage();
        }
    }
    
    
//    public Collections addBookmarksToCollection(Map<String, Object> requestData) {
//        // Save the collection first to generate its ID
//        Collections savedCollection = collectionRepository.save(collection);
//
//        // Set the collection reference for each bookmark
//        bookmarks.forEach(bookmark -> bookmark.setCollections(savedCollection));
//
//        // Save the bookmarks
//        bookmarkRepository.saveAll(bookmarks);
//
//        // Associate the saved bookmarks with the saved collection
//        savedCollection.setBookmark(bookmarks);
//
//        // Save the updated collection with references to bookmarks
//        collectionRepository.save(savedCollection);
//
//        // Return the saved collection
//        return savedCollection;
//    }

    
//    public Collections addBookmarksToCollection(Map<String, Object> requestData) {
//        // Extract collection information from the requestData
//    	long collectionID = sequenceGeneratorService.generateSequence("collection_Id");
//        String collectionName = (String) requestData.get("collectionName");
//        String collectionDescription = (String) requestData.get("collectionDescription");
//
//        // Create a new Collections entity
//        Collections collection = new Collections();
//        collection.setCollectionName(collectionName);
//        collection.setCollectionDescription(collectionDescription);
//
//        // Save the collection first to generate its ID
//        Collections savedCollection = collectionRepository.save(collection);
//
//        // Extract bookmark information from the requestData
//        List<Map<String, Object>> bookmarkDataList = (List<Map<String, Object>>) requestData.get("bookmark");
//        
//        // Create and save Bookmark entities
//        List<Bookmark> bookmarks = bookmarkDataList.stream()
//                .map(bookmarkData -> {
//                    Bookmark bookmark = new Bookmark();
//                    bookmark.setCollections(savedCollection); // Set the reference to the parent collection
//                    bookmark.setBookmarkTitle((String) bookmarkData.get("bookmarkTitle"));
//                    bookmark.setUrl((String) bookmarkData.get("url"));
//                    bookmark.setBookmarkDescription((String) bookmarkData.get("bookmarkDescription"));
//                    // Set other properties as needed
//                    return bookmarkRepository.save(bookmark); // Save and return the bookmark
//                })
//                .toList();
//
//        // Associate the saved bookmarks with the saved collection
//        savedCollection.setBookmark(bookmarks);
//
//        // Save the updated collection with references to bookmarks
//        collectionRepository.save(savedCollection);
//
//        // Return the saved collection
//        return savedCollection;
//    }
   
    public Collections addBookmarksToCollection(Map<String, Object> requestData) {
        try {
            // Use the sequence generator service to generate the collectionID
            long collectionID = sequenceGeneratorService.generateSequence("collection_Id");

            // Extract other collection information from the requestData
            String collectionName = (String) requestData.get("collectionName");
            String collectionDescription = (String) requestData.get("collectionDescription");

            // Find the existing collection or throw an exception if not found
            Collections existingCollection = collectionRepository.findByCollectionID(collectionID)
                    .orElseThrow(() -> new IllegalArgumentException("Collection with ID " + collectionID + " not found!"));

            // Extract bookmark information from the requestData
            List<Map<String, Object>> bookmarkDataList = (List<Map<String, Object>>) requestData.get("bookmark");

            // Create and save Bookmark entities
            List<Bookmark> bookmarks = bookmarkDataList.stream()
                    .map(bookmarkData -> {
                        Bookmark bookmark = new Bookmark();
                        bookmark.setCollections(existingCollection); // Set the reference to the parent collection
                        bookmark.setBookmarkTitle((String) bookmarkData.get("bookmarkTitle"));
                        bookmark.setUrl((String) bookmarkData.get("url"));
                        bookmark.setBookmarkDescription((String) bookmarkData.get("bookmarkDescription"));
                        // Set other properties as needed
                        return bookmarkRepository.save(bookmark); // Save and return the bookmark
                    })
                    .toList();

            // Associate the saved bookmarks with the existing collection
            existingCollection.setBookmarks(bookmarks);

            // Save the updated collection with references to bookmarks
            collectionRepository.save(existingCollection);

            // Return the saved collection
            return existingCollection;
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            // Handle the exception as needed and return an appropriate response
            return null;
        }
    }


    
//    public Optional<Collections> getCollectionToBookmarkByName(String name) {
//        // Extract the collection name from the requestData
//        String collectionName = (String) requestData.get("collectionName");
//        
//        // Find the existing collection by name
//        Optional<Collections> optionalCollection = collectionRepository.findByCollectionName(collectionName);
//
//        // Check if the collection exists
//        if (optionalCollection.isPresent()) {
//            Collections existingCollection = optionalCollection.get();
//
//            // Retrieve the bookmarks associated with the collection if includeBookmarks is true
//            if (requestData.containsKey("includeBookmarks") && (boolean) requestData.get("includeBookmarks")) {
//                List<Bookmark> bookmarks = existingCollection.getBookmark();
//                existingCollection.setBookmark(bookmarks);
//            }
//
//            return Optional.of(existingCollection);
//        } else {
//            // If the collection is not found, return an empty Optional
//            return Optional.empty();
//        }
//    }


//    public ResponseEntity<Object> getCollectionToBookmarkByName(String name) {
//        try {
//            List<Collections> collectionsList = collectionRepository.findByCollectionNameIgnoreCase(name.trim());
//
//            if (!collectionsList.isEmpty()) {
//                List<Map<String, Object>> collectionList = collectionsList.stream().map(collection -> {
//                    Map<String, Object> collectionMap = new HashMap<>();
//                    collectionMap.put("collectionId", collection.getCollectionID());
//                    collectionMap.put("collectionName", collection.getCollectionName());
//                    collectionMap.put("collectionDescription", collection.getCollectionDescription());
//
//                    // Retrieve bookmarks only if includeBookmarks is true
//                    boolean includeBookmarks = true; // Set the default value
//                    if (includeBookmarks) {
//                        List<Bookmark> bookmarks = collection.getBookmark();
//                        collectionMap.put("bookmarks", bookmarks);
//                    }
//
//                    // Add other fields as needed
//                    return collectionMap;
//                }).collect(Collectors.toList());
//
//                return ResponseEntity.ok(collectionList);
//            } else {
//                System.out.println("No collections found for name: " + name);
//                // Handle the case where no collections are found
//                Map<String, String> responseMap = new HashMap<>();
//                responseMap.put("message", "No collections found for name: " + name);
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
//            }
//        } catch (Exception e) {
//            // Log any exceptions for debugging
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(new HashMap<String, String>(){{put("error", e.getMessage());}});
//        }
//    }
//
//    }

    public ResponseEntity<Object> getCollectionToBookmarkByName(String name) {
        try {
            List<Collections> collectionsList = collectionRepository.findByCollectionNameIgnoreCase(name.trim());

            if (!collectionsList.isEmpty()) {
                List<String> formattedCollectionList = collectionsList.stream().map(collection -> {
                    StringBuilder collectionDetails = new StringBuilder();
                    collectionDetails.append("Collection ID: ").append(collection.getCollectionID()).append("\n");
                    collectionDetails.append("Collection Name: ").append(collection.getCollectionName()).append("\n");
                    collectionDetails.append("Collection Description: ").append(collection.getCollectionDescription()).append("\n");

                    // Retrieve bookmarks only if includeBookmarks is true
                    boolean includeBookmarks = true; // Set the default value
                    if (includeBookmarks) {
                        List<Bookmark> bookmarks = collection.getBookmarks();
                        collectionDetails.append("Bookmarks: ").append(bookmarks).append("\n");
                    }

                    // Add other fields as needed

                    collectionDetails.append("\n");
                    return collectionDetails.toString();
                }).collect(Collectors.toList());

                StringBuilder response = new StringBuilder();
                for (String formattedCollection : formattedCollectionList) {
                    response.append(formattedCollection);
                }

                return ResponseEntity.ok(response.toString());
            } else {
                System.out.println("No collections found for name: " + name);
                // Handle the case where no collections are found
                Map<String, String> responseMap = new HashMap<>();
                responseMap.put("message", "No collections found for name: " + name);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMap);
            }
        } catch (Exception e) {
            // Log any exceptions for debugging
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new HashMap<String, String>(){{put("error", e.getMessage());}});
        }
    }
}


